intMaxJava= 2147483647 # maximum positive int (4 bytes varible)
print (intMaxJava)
print (type(intMaxJava))

longMaxJava= 9223372036854775807 #maximum positive long (8 bytes variable)
print (longMaxJava)
print (type(longMaxJava))

pythonIntUnboundery=intMaxJava+longMaxJava
print (pythonIntUnboundery)
print (type(pythonIntUnboundery))

pythonIntUnboundery=pythonIntUnboundery*pythonIntUnboundery
print (pythonIntUnboundery)
print (type(pythonIntUnboundery))
