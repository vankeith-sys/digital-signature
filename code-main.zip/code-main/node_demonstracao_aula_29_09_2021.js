//desvio condicional
let x=6;
let y=6;
let valorBooleano = y<x ;
//if/else/ else if
/*
if(valorBooleano){
    console.log("Olá!");
}
*/
/*
if(valorBooleano){
    console.log("Olá!");
}else{
    console.log("Tchau!!!");
}
*/
/*
if(x>y){
    console.log("Olá!");
}else if(y>x){
    console.log("Tchau!!!");
}else {
    console.log("Tudo bem??");
}



//switch/case

switch(x){
    case 1:
        console.log("Bom dia!");
        break;
    case 2:
        console.log("Boa tarde!");
        break;
    case 3:
        console.log("Boa noite!");
        break;
    default:
        console.log("Que horas são??");
}
*/
//laços de repetição
let contador=0;
//while
while(contador>=0 && contador<100){
    console.log("Contador....", contador);
    //contador=contador+1;
    contador++;
}
console.log("Contador", contador);
//do-while

//for
console.log("Fim!");
