nota_m1=5.6
print(nota_m1, type(nota_m1))
nota_m1=10.1
nota_m2=10.2
conceito='A'
cancelado=True
validadeVencida=False
quantidade_material=99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999123456789
print(nota_m1,type(nota_m1))
print(conceito, type(conceito))
print(nota_m2, type(nota_m2))
print(quantidade_material, type(quantidade_material))
print(validadeVencida,type(validadeVencida))
soma=nota_m1+nota_m2
print("soma", nota_m1+nota_m2,type(soma))
media=soma/2
print("media", media, type(media))
print("Maior",nota_m1>nota_m2)
print("Menor ou igual",nota_m1<=nota_m2)
print("igual",nota_m1==nota_m2)
print("diferente",nota_m1!=nota_m2)
print("igual estrito",  nota_m1==nota_m2 and type(nota_m1)==type(nota_m2) )
print("igual tipo ou valor",  nota_m1==nota_m2 or type(nota_m1)==type(nota_m2) )
print (not(True))
'''
Text Type:	str
Numeric Types:	int, float, complex
Sequence Types:	list, tuple, range
Mapping Type:	dict
Set Types:	set, frozenset
Boolean Type:	bool
Binary Types:	bytes, bytearray, memoryview

name="Python"
majorVersion=3
version=3.7
authorized=False
print(type(name))
print(type(majorVersion))
print(type(version))
print(type(authorized))
print(type(majorVersion<version))
print (False & False)
print (False | True)
print (False and False)
print (False or True)
'''
