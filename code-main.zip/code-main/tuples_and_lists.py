list=[]
tuple=()

print(type(list))
print(type(tuple))


tuple=("Legolas","Frodo", "Aragorn")
print(tuple[0])
print(tuple[1])
print(tuple[2])
#tuple[0]="Gandolf"
tuple.append("Gandolf")
for x in tuple:
    print("tuple element:",x)


list=["Legolas","Frodo", "Aragorn"]
print(list[0])
print(list[1])
print(list[2])
list.append("Gandolf")
for x in list:
    print("list element:", x)




#list.append("Gandolf")
#tuple.append("Gandolf")


